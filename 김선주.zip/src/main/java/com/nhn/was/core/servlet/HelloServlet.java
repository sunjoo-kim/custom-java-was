package com.nhn.was.core.servlet;

import com.nhn.was.core.request.DefaultHttpRequest;
import com.nhn.was.core.response.HttpResponse;
import com.nhn.was.core.response.HttpResponseBody;

public class HelloServlet implements Servlet {
    @Override
    public HttpResponse service(DefaultHttpRequest request, HttpResponse response) {
        HttpResponseBody responseBody = new HttpResponseBody("<html><body><h1>Hello, World!</h1></body></html>");
        return HttpResponse.getOkResponse(responseBody);
    }
}
