package com.nhn.was.core.servlet.foo;

import com.nhn.was.core.request.DefaultHttpRequest;
import com.nhn.was.core.response.HttpResponse;
import com.nhn.was.core.response.HttpResponseBody;
import com.nhn.was.core.servlet.Servlet;

public class BarServlet implements Servlet {
    @Override
    public HttpResponse service(DefaultHttpRequest request, HttpResponse response) {
        HttpResponseBody responseBody = new HttpResponseBody("<html><body><h1>foo bar</h1></body></html>");
        return HttpResponse.getOkResponse(responseBody);
    }
}
