package com.nhn.was.core.servlet;

import com.nhn.was.core.request.DefaultHttpRequest;
import com.nhn.was.core.response.HttpResponse;

public interface Servlet {
    HttpResponse service(DefaultHttpRequest request, HttpResponse response);
}
