package com.nhn.was.core.request;

public interface HttpRequest {
    HttpRequestLine requestLine();
}
