package com.nhn.was.core.filter;

import com.nhn.was.core.request.HttpRequest;
import com.nhn.was.core.response.HttpResponse;

public class DirectoryTraversalFilter implements RequestFilter {
    @Override
    public boolean doFilter(HttpRequest request, HttpResponse response) {
        return  !request.requestLine().path().contains("..");
    }
}