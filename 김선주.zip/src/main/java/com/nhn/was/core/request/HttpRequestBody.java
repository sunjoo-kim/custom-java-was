package com.nhn.was.core.request;

public record HttpRequestBody(String content, int contentLength) {
}